using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FlexiSecure.Models
{
    public class UserRegisterRequest
    {
        [Required,MinLength(3, ErrorMessage ="Enter a valid name")]
        public string Name { get; set; } = string.Empty;
        
        [Required, EmailAddress]
        public string Email { get; set; } = string.Empty;
        
        [Required, MinLength(6,ErrorMessage ="Please enter at least 6 characters ")]
        public string Password { get; set; } = string.Empty;
        
        [Required, Compare("Password")]
        public string ConfirmPassword{get; set; } = string.Empty;


        
    }
}