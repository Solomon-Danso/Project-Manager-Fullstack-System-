using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectManager.Models
{
    public class Project
    {
        public int Id {get; set;}
        public string name {get;set;}
        public string description {get;set;}
        public DateTime dueDate {get;set;}
        public double cost {get;set;}
        public string developer {get;set;}
        public string customer {get;set;}
        public string status {get;set;}
        
        
    }
}