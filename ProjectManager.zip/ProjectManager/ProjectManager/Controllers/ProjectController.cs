using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProjectManager.Data;
using ProjectManager.Models;

namespace ProjectManager.Controllers
{
    [ApiController]
    [Route("api/Projects")]
    public class ProjectController : ControllerBase
    {
        private readonly DataContext _context;
        public ProjectController(DataContext context){
            _context = context;
        }
    [HttpPost()]
    public async Task<IActionResult> AddProject(Project project){
       
       //Call the Project.cs model to create a skeleton 
        var my_project = new Project{
          name = project.name,
          description = project.description,
          dueDate = project.dueDate,
          cost = project.cost,
          developer = project.developer,
          customer = project.customer,
          status = project.status
        };
        _context.Projects.Add(my_project);
        await _context.SaveChangesAsync();
        return Ok("Projects Created Successfully");

   
    }
      [HttpGet()]
        public async Task<ActionResult<IEnumerable<Project>>> GetItems()
        {
            var items = await _context.Projects.ToListAsync(); // Replace "YourModels" with your actual DbSet name

            return Ok(items);
        }

        [HttpGet("{Id}")]
        public async Task<ActionResult<Project>> GetItem(int Id){
            var item = await _context.Projects.FindAsync(Id);
            if (item == null){
                return NotFound();
            }
            return Ok(item);


        }







         [HttpPut("{id}")]
          public async Task<IActionResult> UpdateItem(int id, Project updatedItem){
            if (id != updatedItem.Id)
            {
                return BadRequest("The IDS DONT MATCH"); // Returns HTTP 400 if the ID in the route does not match the ID in the updated item
            }

             _context.Entry(updatedItem).State = EntityState.Modified;

              try
            {
                await _context.SaveChangesAsync();
            }
            catch(DbUpdateConcurrencyException){
                 if (!ItemExists(id))
                {
                    return NotFound(); // Returns HTTP 404 if the item with the specified ID is not found
                }
                else
                {
                    throw;
                }
            }
             return NoContent();
            
          }
           private bool ItemExists(int id)
        {
            return _context.Projects.Any(e => e.Id == id); 
        }

        [HttpDelete("{id}")]
public async Task<IActionResult> DeleteItem(int id)
{
    var item = await _context.Projects.FindAsync(id); 

    if (item == null)
    {
        return NotFound("Item not found");
    }

    _context.Projects.Remove(item); 
    await _context.SaveChangesAsync();

    return NoContent(); 
}







    }





    }
    