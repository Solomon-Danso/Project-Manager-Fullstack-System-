using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FlexiSecure.Models;
using Microsoft.EntityFrameworkCore;
using ProjectManager.Models;

namespace ProjectManager.Data
{
    public class DataContext : DbContext
    {
        public DataContext(): base(){
            
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseSqlServer("Server=localhost,1433;Database=Projects;User=sa;Password=HydotTech;TrustServerCertificate=true;");
        }

        public DbSet<Project> Projects => Set<Project>();
        public DbSet<User> Users => Set<User>();


    }
}