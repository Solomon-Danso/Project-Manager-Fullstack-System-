window.onload = function(){
    Projects()
  }
  
  const uri = 'api/Projects';
  const auth = "api/Auth";
  let projects = [];
  
  function getProject(){
      fetch(uri)
      .then(response => response.json())
      .catch(error=> console.error('Unable to get items.', error))
  }
  /*
  
  Create a Project
  
  */
  
  function addProject(){
      const addCustomer = document.getElementById("customer");
      const addName = document.getElementById("name");
      const addDescription = document.getElementById("description");
      const addDuedate = document.getElementById("duedate");
      const addCost = document.getElementById("cost");
      const addDeveloper = document.getElementById("developer");
      const addStatus = document.getElementById("status");
      
      const projectItem = {
          customer: addCustomer.value.trim(),
          name: addName.value.trim(),
          description: addDescription.value.trim(),
          dueDate: addDuedate.value.trim(),
          cost : addCost.value.trim(),
          developer : addDeveloper.value.trim(),
          status: addStatus.value.trim(),
      };
      fetch(uri, {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(projectItem)
        })
        .then(response => response.json)
        .then(()=>{
          getProject();
          addCustomer.value = "";
          addStatus.value = "";
          addDescription.value = "";
          addDuedate.value = "";
          addCost.value = "";
          addDeveloper.value = "";
          addName.value = "";
          showDashboard(data);
  
        })
        .catch(error => console.error('Unable to add Project.', error));    
  
  }
  
  
  /*
  
  Update a Project
  
  */
  function updateProject(){
    projectId = document.getElementById('edit-id').value.trim();
    const projectItem = {
      Id : document.getElementById('edit-id').value.trim(),
      customer: document.getElementById('edit-customer').value.trim(),
      name: document.getElementById('edit-name').value.trim(),
      description: document.getElementById('edit-description').value.trim(),
      dueDate: document.getElementById('edit-duedate').value.trim(),
      cost: document.getElementById('edit-cost').value.trim(),
      developer: document.getElementById('edit-developer').value.trim(),
      status:document.getElementById('edit-status').value.trim(),
    };
  fetch(`${uri}/${projectId}`,{
    method: 'PUT',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(projectItem)  
  })
  .then(response => response.json) 
  .then(() =>{
      getProject();
      document.getElementById('edit-id').value = "";
      document.getElementById('edit-customer').value = "";
      document.getElementById('edit-name').value = ""; 
      document.getElementById('edit-description').value = ""; 
      document.getElementById('edit-duedate').value = ""; 
      document.getElementById('edit-cost').value = ""; 
      document.getElementById('edit-developer').value = "";
      document.getElementById('edit-status').value = "";
  
  })
  .catch(error => console.error('Unable to update projects.', error));
  return false;
  
  }
  
  /*
  
  DELETE PROJECT 
  
  */
  
  
  function deleteProject() {
    projectId = document.getElementById("delete-id").value.trim();
  
  
    fetch(`${uri}/${projectId}`, {
      method: 'DELETE'
    })
   
    .then(() => {
      getProject();
      document.getElementById("delete-id").value = "";
    })
    .catch(error => console.error('Unable to delete item.', error));
  }
  
  async function Projects(){
  try{
    const response = await fetch(uri);
    const items = await response.json();
  
    const container = document.getElementById("container");
  
  

  
    items.forEach(function(item){
      const Card = document.createElement("div");
      Card.className = "card"
      
      const customer = document.createElement("div");
      customer.className = "card-2";
      customer.innerHTML = `&#128188;&nbsp; ${item.customer}`;
      Card.appendChild(customer);
  
  
      const Id = document.createElement("div");
      Id.className = "card-1";
      Id.innerHTML = `<span >&#128273 ID:</span> ${item.id}`;
      Card.appendChild(Id);
  
      const name = document.createElement("div");
      name.className = "card-1";
      name.innerHTML = `<span >&#128450 Name:</span> ${item.name}`;
      Card.appendChild(name);
  
      const description = document.createElement("div");
      description.className = "card-1";
      description.innerHTML = `<span >&#128452 Description:</span> ${item.description}`;
      Card.appendChild(description);
  
      const cost = document.createElement("div");
      cost.className = "card-1";
      cost.innerHTML = `<span >&#128181 Cost:</span> GHS ${item.cost}`;
      Card.appendChild(cost);
  
      const duedate = document.createElement("div");
      duedate.className = "card-1";
      duedate.innerHTML = `<span >&#128198 Duedate:</span> ${item.dueDate}`;
      Card.appendChild(duedate);
  
      const developer = document.createElement("div");
      developer.className = "card-1";
      developer.innerHTML = `<span >&#128100 Developer:</span> ${item.developer}`;
      Card.appendChild(developer);

      const status = document.createElement("div");
      status.className = "card-1";
      status.innerHTML = `<span >&#128640 Status:</span>${item.status}`;
      Card.appendChild(status);
  
      container.appendChild(Card)
     
    })
   
  }
  catch(error){
    console.error("Error fetching Items",error);
  }
  
  }
  
  async function verifyUser() {
    const token = document.getElementById("token").value.trim();
  
    try {
      const response = await fetch(auth+"/verify?token=" + token, {
        method: "POST"
      });
  
      const data = await response.text();
  
      if (response.ok) {
        // Verification successful
        alert("Verification successful! " + data);
        document.getElementById("signup").style.display = "none";
        document.getElementById("veriToken").style.display = "none";
        document.getElementById("loginContainer").style.display="flex"
      } else {
        // Verification failed
        alert("Verification failed: " + data);
      }
    } catch (error) {
      console.error("Error verifying user:", error);
    }
  }
  
  
  //Signup
  async function signUP(){
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password1 = document.getElementById("password1").value;
    const password2 = document.getElementById("password2").value;
  
  const register = {
    Name: name.trim(),
    Email: email.trim(),
    Password: password1.trim(),
    ConfirmPassword: password2.trim()
  }
  try{
  
    const response = await fetch(auth+"/register",{
      method: "POST",
      headers: {
        
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(register),
    })
    const data = await response.json();
    if (response.ok){
      alert(data);
      document.getElementById("signup").style.display = "none";
      document.getElementById("veriToken").style.display="flex";
    }
    else{
      alert(data)
    }
  
  }
  catch(error){
    console.error("Error registering user:", error);
  }
  
  
  }
  
  
  
  
  //Login Function
  async function authenticateUser() {
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
  
    
    const login = {
      Email:username,
      Password:password
    }
  
  
    try {
      const response = await fetch(auth+'/login', {
        method: "POST",
        headers: {
          
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(login)
      });
  
      const data = await response.json();
  
  
      if (response.ok) {
        // Authentication successful
        showDashboard(data);
        document.getElementById("loginContainer").style.display = "none";
      } else {
        // Authentication failed
        alert("Authentication failed: " + data);
      }
    } catch (error) {
      console.error("Error authenticating user:", error);
    }
  }
  
  function showDashboard(data) {
      const welcomeMessage = document.getElementById("welcomeMessage");
    document.getElementById("signup").style.display = "none";
    document.getElementById("veriToken").style.display = "none";
    document.getElementById("loginContainer").style.display = "none";
    document.getElementById("dashboardContainer").style.display="flex";
    
    ;
  
    // Display the username in the welcome message
    welcomeMessage.textContent = data;
  
  
  }
  
function hysignup(){
    document.getElementById("signup").style.display = "flex";
    document.getElementById("loginContainer").style.display = "none";
}

function hyverify(){
    document.getElementById("veriToken").style.display = "flex";
    document.getElementById("signup").style.display = "none";
}

function opener(){
    document.getElementById("sidebar").style.display = "flex";
    document.getElementById("display_projects").style.display = "none";
    document.getElementById("opener").style.display ='none';

}
function hyupdate(){
    document.getElementById("hyupdate").style.display = "flex"
    document.getElementById("hydelete").style.display = "none"
    document.getElementById("hyaddnew").style.display = "none"
}

function hydelete(){
    document.getElementById("hydelete").style.display = "flex"
    document.getElementById("hyaddnew").style.display = "none"
    document.getElementById("hyupdate").style.display = "none"
}

function hyaddnew(){
    document.getElementById("hyaddnew").style.display = "flex"
    document.getElementById("hyupdate").style.display = "none"
    document.getElementById("hydelete").style.display = "none"

}

  